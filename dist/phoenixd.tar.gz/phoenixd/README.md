./dist contains .tar.gz to be uploaded onto MyNodeBTC Marketplace Community App.

NO WARRANTIES OF ANY KIND!

TAKE, KEEP AND VERYFY BACKUP DATA RESTORABILITY BY YOURSELF!
