./dist contains .tar.gz to be uploaded onto MyNodeBTC Marketplace Community App.

NO WARRANTIES OF ANY KIND!

TAKE, KEEP AND VERYFY BACKUP DATA RESTORABILITY BY YOURSELF!

# ToDo
### phoenix-cli needs 
* commandline wrapper bin to docker exec

# Changelog

### Change to user tlinid repo
-remove "patching" from install_phoenixd.sh,
-and use phoenixd upstream commits
-and use phoenixd upstream customized Dockerfile

### v0.5.1-patched+cli
-Enable phoenix-cli build by patching Dockerfile

### Commit f6236f0
-Fix start

### Initial Version
-Done
