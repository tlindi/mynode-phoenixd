./dist contains .tar.gz to be uploaded onto MyNodeBTC Marketplace Community App.

NO WARRANTIES OF ANY KIND!

TAKE, KEEP AND VERYFY BACKUP DATA RESTORABILITY BY YOURSELF!

# KNOWN ISSUES
### phoenix-cli needs 
* bitcoin users ~.phoenix link to hdd/mynode/phoenixd
* commandline wrapper bin to docker exec

###old screenshot 
* ToDo

# Changelog

### Commit f6236f0
-Fix start

### Initial Version
-Done
