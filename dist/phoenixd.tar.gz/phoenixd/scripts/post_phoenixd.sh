#!/bin/bash

# This will run after launching the application